# Udemy API Automation Practice

    This project is an example of API Automation testing.
    Tech Stack: Java 11, Junit 5, Cucumber, Lombok

### API Documentation

https://restful-booker.herokuapp.com/apidoc/

### How to run tests
    1- open Terminal/Console
    2- type: mvn clean test

### How to run tests from Intellij
1) Search for class `JunitDefault`
2) Click with right button and select Run.

It will automatically run Junit Default tests.


