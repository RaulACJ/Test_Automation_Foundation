package com.foundations.common.model;

import lombok.Data;

@Data
public class AuthResponse {
    public String token;
}
