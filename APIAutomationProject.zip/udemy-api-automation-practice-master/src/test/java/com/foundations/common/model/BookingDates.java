package com.foundations.common.model;

import lombok.Data;

@Data
public class BookingDates {
    public String checkin;
    public String checkout;
}
